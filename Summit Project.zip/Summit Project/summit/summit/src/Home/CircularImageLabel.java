
package Home;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;

public class CircularImageLabel extends JLabel {
    private BufferedImage image;

    public CircularImageLabel(BufferedImage image) {
        this.image = image;
        setOpaque(false); // Make the label transparent
        setHorizontalAlignment(SwingConstants.CENTER);
        setVerticalAlignment(SwingConstants.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        // Draw the thick ombre border
        Graphics2D g2d = (Graphics2D) g;

        // Create a gradient paint for the border
        GradientPaint gradientPaint = new GradientPaint(0, 0, Color.PINK, 
                                                         getWidth(), getHeight(), Color.ORANGE);
        g2d.setPaint(gradientPaint);
        g2d.fillOval(0, 0, getWidth(), getHeight());

        // Draw the circular image inside the label
        g2d.setClip(new Ellipse2D.Double(0, 0, getWidth(), getHeight()));
        if (image != null) {
            g2d.drawImage(image, 0, 0, getWidth(), getHeight(), null);
        }
        
        // Reset the clip
        g2d.setClip(null);
        
        // Draw text in the center of the circle
        g2d.setColor(Color.BLACK); // Set text color
        g2d.setFont(getFont());
        FontMetrics metrics = g2d.getFontMetrics();
        String text = getText();
        int textWidth = metrics.stringWidth(text);
        int textHeight = metrics.getHeight();
        g2d.drawString(text, (getWidth() - textWidth) / 2, (getHeight() + textHeight) / 2 - 2); // Center the text

        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(100, 100); // Set the preferred size for the circular label
    }
}