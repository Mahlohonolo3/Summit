import Database.DatabaseManager;
import com.sun.jdi.connect.spi.Connection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class AdminPanel extends JFrame {

private JDialog reportDialog;
private DefaultTableModel reportModel;
private JTable reportTable;
private JTable usersTable;
private DefaultTableModel usersModel;
    private JTable searchResultsTable;
    private DefaultTableModel searchResultsModel;
    private JPanel searchResultsPanel;
    private JButton viewTransactionsButton, deleteUserButton, generateReportButton, searchButton, adminProfileButton, exitButton;
    
    private DatabaseManager databaseManager;

public AdminPanel() {
        databaseManager = new DatabaseManager();
        databaseManager.connect();

        setTitle("Admin Panel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Navigation Panel
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(224, 17, 95));
        JLabel titleLabel = new JLabel("Summit Personal Finance Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        navPanel.add(titleLabel);
        add(navPanel, BorderLayout.NORTH);

        // Users Table
       /* usersModel = new DefaultTableModel(new String[]{"User ID", "Name", "Username", "Email", "Profile Picture"}, 0);
        usersTable = new JTable(usersModel);
        usersTable.setFillsViewportHeight(true);
        usersTable.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(usersTable);
        scrollPane.setPreferredSize(new Dimension(1200, 600));

        JPanel tablePanel = new JPanel(new GridBagLayout());
        tablePanel.add(scrollPane);
        add(tablePanel, BorderLayout.CENTER);*/

        // Search Results Table (Initially Hidden)
        searchResultsModel = new DefaultTableModel(new String[]{"User ID", "Name", "Username", "Email", "Profile Picture"}, 0);
        searchResultsTable = new JTable(searchResultsModel);
        searchResultsTable.setFillsViewportHeight(true);
        searchResultsTable.setBackground(Color.WHITE);

        searchResultsPanel = new JPanel(new BorderLayout());
        searchResultsPanel.setBorder(BorderFactory.createTitledBorder("Search Results"));
        searchResultsPanel.add(new JScrollPane(searchResultsTable), BorderLayout.CENTER);
        
        // Add close button for search results
        JButton closeSearchButton = new JButton("Close Search Results");
        closeSearchButton.addActionListener(e -> {
            searchResultsPanel.setVisible(false);
            revalidate();
            repaint();
        });
        searchResultsPanel.add(closeSearchButton, BorderLayout.SOUTH);
        
        searchResultsPanel.setVisible(false); // Initially hidden
        add(searchResultsPanel, BorderLayout.SOUTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1));
        buttonPanel.setBackground(new Color(240, 248, 255));

    /*    viewTransactionsButton = new JButton("View Transactions");
        viewTransactionsButton.setBackground(Color.BLUE);
        viewTransactionsButton.setForeground(Color.WHITE);
        viewTransactionsButton.addActionListener(e -> viewTransactions());
        buttonPanel.add(viewTransactionsButton);*/

        deleteUserButton = new JButton("Delete User");
        deleteUserButton.setBackground(Color.BLUE);
        deleteUserButton.setForeground(Color.WHITE);
        deleteUserButton.addActionListener(e -> deleteUser());
        buttonPanel.add(deleteUserButton);

        generateReportButton = new JButton("Generate Report");
        generateReportButton.setBackground(Color.BLUE);
        generateReportButton.setForeground(Color.WHITE);
        generateReportButton.addActionListener(e -> generateReport());
        buttonPanel.add(generateReportButton);

        searchButton = new JButton("Search User");
        searchButton.setBackground(Color.BLUE);
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(e -> searchUser());
        buttonPanel.add(searchButton);

   
        exitButton = new JButton("Exit");
        exitButton.setBackground(Color.BLUE);
        exitButton.setForeground(Color.WHITE);
        exitButton.addActionListener(e -> System.exit(0));
        buttonPanel.add(exitButton);

        add(buttonPanel, BorderLayout.EAST);

        setVisible(true);
    }

   
    private int calculateCreditScore(User user) {
        double balance = user.getCurrentBalance();
        double liabilities = user.getLiabilities();
        String accountNumber = user.getAccountNumber();

        // Base score based on balance and liabilities
        int baseScore;
        if (balance >= liabilities) {
            baseScore = 600; // Excellent score
        } else if (balance >= liabilities * 0.75) {
            baseScore = 650; // Good score
        } else if (balance >= liabilities * 0.5) {
            baseScore = 500; // Fair score
        } else {
            baseScore = 300; // Poor score
        }

        // Adjust score based on account number
        if (accountNumber.startsWith("ACC1")) {
            baseScore += 50;
        } else if (accountNumber.startsWith("ACC2")) {
            baseScore += 30;
        }

        return Math.min(Math.max(baseScore, 300), 850); // Score should be between 300 and 850
    }

   /* private void viewTransactions() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow >= 0) {
            String userName = (String) usersModel.getValueAt(selectedRow, 0);
            JOptionPane.showMessageDialog(this, "Viewing transactions for: " + userName);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to view transactions.");
        }
    }
*/
    private void deleteUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow >= 0) {
            usersModel.removeRow(selectedRow); // Remove user from the table
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.");
        }
    }

   private void generateReport() {
    reportDialog = new JDialog(this, "User Report", true);
    reportDialog.setLayout(new BorderLayout());
    reportDialog.setSize(800, 600);
    reportDialog.setLocationRelativeTo(this);

    // Create the table model with columns
    reportModel = new DefaultTableModel(
        new String[]{
            "User ID", "Name", "Username", "Email", 
            "Account Type", "Balance", "Liabilities"
        }, 0
    );
    
    reportTable = new JTable(reportModel);
    reportTable.setFillsViewportHeight(true);
    reportTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    
    // Add a scroll pane
    JScrollPane scrollPane = new JScrollPane(reportTable);
    reportDialog.add(scrollPane, BorderLayout.CENTER);
    
    // Create a panel for the title
    JPanel titlePanel = new JPanel();
    titlePanel.setBackground(new Color(224, 17, 95));
    JLabel titleLabel = new JLabel("User Financial Report");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
    titleLabel.setForeground(Color.WHITE);
    titlePanel.add(titleLabel);
    reportDialog.add(titlePanel, BorderLayout.NORTH);
    
    // Add a close button at the bottom
    JButton closeButton = new JButton("Close Report");
    closeButton.addActionListener(e -> reportDialog.dispose());
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(closeButton);
    reportDialog.add(buttonPanel, BorderLayout.SOUTH);
    
    // Fetch and display data
    try {
        String query = 
            "SELECT u.user_id, u.name, u.username, u.email, " +
            "a.account_type, a.balance, a.liabilities " +
            "FROM users u " +
            "LEFT JOIN account a ON u.user_id = a.user_id";
            
             ResultSet rs = DatabaseManager.executePreparedQuery(query);
        
        DecimalFormat currencyFormat = new DecimalFormat("#,##0.00");
        
        while (rs.next()) {
            Object[] row = {
                rs.getInt("user_id"),
                rs.getString("name"),
                rs.getString("username"),
                rs.getString("email"),
                rs.getString("account_type"),
                currencyFormat.format(rs.getDouble("balance")),
                currencyFormat.format(rs.getDouble("liabilities"))
            };
            reportModel.addRow(row);
        }
        
        // Add sorting capability
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(reportModel);
        reportTable.setRowSorter(sorter);
        
        // Set column widths
        TableColumn column;
        for (int i = 0; i < reportTable.getColumnCount(); i++) {
            column = reportTable.getColumnModel().getColumn(i);
            if (i == 0) { // User ID
                column.setPreferredWidth(60);
            } else if (i == 3) { // Email
                column.setPreferredWidth(200);
            } else {
                column.setPreferredWidth(120);
            }
        }
        
        if (rs != null) {
            rs.close();
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error generating report: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
        e.printStackTrace();
    }
    
    reportDialog.setVisible(true);
}

   private void searchUser() {
        String searchName = JOptionPane.showInputDialog("Enter user name to search:");
        
        if (searchName == null || searchName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a valid username.");
            return;
        }
        
        try {
            String query = "SELECT user_id, name, username, email, profile_picture " +
                   "FROM users " +
                   "WHERE name LIKE ?";
            ResultSet rs = DatabaseManager.executePreparedQuery(query, "%" + searchName + "%");
            
            // Clear existing search results
            searchResultsModel.setRowCount(0);
            
            boolean found = false;
            while (rs.next()) {
                found = true;
                Object[] row = new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("profile_picture")
                };
                searchResultsModel.addRow(row);
            }
            
            if (found) {
                // Show search results panel and adjust layout
                searchResultsPanel.setVisible(true);
                revalidate();
                repaint();
            } else {
                searchResultsPanel.setVisible(false);
                JOptionPane.showMessageDialog(this,
                    "User not found: " + searchName,
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
                );
            }
            
            if (rs != null) {
                rs.close();
            }
            
        } catch (SQLException e) {
            searchResultsPanel.setVisible(false);
            JOptionPane.showMessageDialog(this,
                "Database error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
            e.printStackTrace();
        }
    }

    private String formatCurrency(double amount) {
        DecimalFormat formatter = new DecimalFormat("#,##0.00");
        return formatter.format(amount);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminPanel::new);
    }

    private static class User {
        private final String name;
        private final double currentBalance;
        private final double liabilities;
        private final String accountNumber;

        public User(String name, double currentBalance, double liabilities, String accountNumber) {
            this.name = name;
            this.currentBalance = currentBalance;
            this.liabilities = liabilities;
            this.accountNumber = accountNumber;
        }

        public String getName() {
            return name;
        }

        public double getCurrentBalance() {
            return currentBalance;
        }

        public double getLiabilities() {
            return liabilities;
        }

        public String getAccountNumber() {
            return accountNumber;
        }
    }
}