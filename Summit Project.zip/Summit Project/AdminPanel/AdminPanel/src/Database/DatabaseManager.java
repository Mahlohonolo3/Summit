package Database;
import java.sql.*;
public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/summit";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private static Connection connection;
    private static Statement statement;

    public static Connection getConnection() {
        return connection;
    }

    public static void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to the database");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

  public static ResultSet executePreparedQuery(String query, Object... parameters) {
    ResultSet resultSet = null;
    try {
        PreparedStatement pstmt = connection.prepareStatement(query);
        for (int i = 0; i < parameters.length; i++) {
            pstmt.setObject(i + 1, parameters[i]);
        }
        resultSet = pstmt.executeQuery();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return resultSet;
}

    // Main method for testing
    public static void main(String[] args) {
        connect(); // Attempt to connect to the database

        // Optional: Execute a test query to verify the connection
        String testQuery = "SELECT * FROM users"; // Replace with your actual table name
        ResultSet rs = executeQuery(testQuery);

        try {
            if (rs != null) {
                while (rs.next()) {
                    // Assuming your table has a column named 'column_name'
                    System.out.println("Data: " + rs.getString("name")); // Replace with your actual column name
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close(); // Close ResultSet if it's not null
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static ResultSet executeQuery(String testQuery) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
